# HRMS

**ERD:** https://drawsql.app/teams/mnhs-team/diagrams/hrms#

**figma:** https://www.figma.com/design/PSKpT3C9FKpEEcntOZbUPF/TEAM-1-Project-figma?node-id=0-1&t=phjeCemxaNNMVGsE-0
